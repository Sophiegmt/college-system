from app.values.value_composite import ValueComposite
from app.values.day_menu_value import DayMenuValue


class WeekMenuValue(ValueComposite):
    def __init__(self, days_menus):
        super(WeekMenuValue, self).initialize({})

        week_list = []
        for menu in days_menus:
            week_list.append(DayMenuValue(menu).to_dict())

        self.serialize_with(list=week_list)
