from app.values.value_composite import ValueComposite


class DayMenuValue(ValueComposite):
    def __init__(self, day_menu):
        super(DayMenuValue, self).initialize({})
        self.serialize_with(day=day_menu['day'])

        meals = []

        for meal in day_menu['meal']:
            new_meal = {}

            info = []
            for information in meal['info']:
                new_info = {
                    'menu': information['menu'],
                    'name': information['name'],
                    'type': information['type']
                }
                info.append(new_info)

            new_meal['info'] = info
            new_meal['type'] = meal['type']
            meals.append(new_meal)

        self.serialize_with(meals=meals)
