from app.values.value_composite import ValueComposite


class LogsValue(ValueComposite):
    """Used to represent an error that might occur in the API.

    Attributes:
        error_message: A string describing the error message
    """

    def __init__(self, log_file):
        super(LogsValue, self).initialize({})

        logs_list = []

        with open(log_file) as fp:
            for line in reversed(list(fp)):
                log = {'text': line}
                logs_list.append(log)


        self.serialize_with(list=logs_list)
