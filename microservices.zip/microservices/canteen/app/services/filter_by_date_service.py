from flask import current_app


class FilterByDateService():
    '''
        Service to filter the canteen meals
        by a specific date
    '''

    def __init__(self, payload, date):
        self.payload = payload
        self.date = date

    def call(self):
        current_app.logger.info(f'Filtering Fenix canteen data by date [{self.date}]...')

        date = self._parse_date(self.date)

        result_data = None
        for day in self.payload:
            print(day['day'])
            if day['day'] == date:
                result_data = day

        return result_data

    @staticmethod
    def _parse_date(date):
        '''
            Replaces - character by /
        '''
        return date.replace("-", "/")
