'''
    routes.py

    This file contains the endpoints of the canteen blueprint
'''
import os
from http import HTTPStatus
from flask import current_app
from app.api import bp
# Services
from app.services.request_fenix_data_service import RequestFenixDataService
from app.services.filter_by_date_service import FilterByDateService
# Values
from app.values.api_error_value import APIErrorValue
from app.values.logs_value import LogsValue
from app.values.day_menu_value import DayMenuValue
from app.values.week_menu_value import WeekMenuValue
# Auth decorators
from app.decorators.auth_decorator import requires_api_auth


@bp.route("/", methods=['GET'])
@requires_api_auth
def get_canteen_data():
    '''
        Endpoint used to request the canteen data
        from Técnico API
    '''
    try:
        canteen_data = RequestFenixDataService().call()

    except Exception:
        current_app.logger.info(f'GET /canteen - {HTTPStatus.SERVICE_UNAVAILABLE}')
        return APIErrorValue("Failed to query Fenix").json(HTTPStatus.SERVICE_UNAVAILABLE)

    data_json = canteen_data.json()
    current_app.logger.info(f'GET /canteen - {HTTPStatus.OK}')
    return WeekMenuValue(data_json).json(HTTPStatus.OK)


@bp.route("/<string:date>", methods=['GET'])
@requires_api_auth
def get_canteen_data_by_date(date):
    '''
        Endpoint used to request the canteen data
        from Técnico API, filtering by a specific
        date.

        date format: 25-11-2019
    '''
    try:
        canteen_data = RequestFenixDataService().call()

    except Exception:
        current_app.logger.info(f'GET /canteen/ - {HTTPStatus.SERVICE_UNAVAILABLE}')
        return APIErrorValue('Failed to request canteen data!').json(HTTPStatus.SERVICE_UNAVAILABLE)

    if date is None:
        current_app.logger.info(f'GET /canteen/ - {HTTPStatus.BAD_REQUEST}')
        return APIErrorValue('Invalid date requested!').json(HTTPStatus.BAD_REQUEST)

    filtered_data = FilterByDateService(payload=canteen_data.json(), date=date).call()

    if filtered_data is None:
        current_app.logger.info(f'GET /canteen/ - {HTTPStatus.BAD_REQUEST}')
        return APIErrorValue('Invalid data format requested!').json(HTTPStatus.BAD_REQUEST)

    current_app.logger.info(f'GET /canteen/{date} - {HTTPStatus.OK}')
    return DayMenuValue(filtered_data).json(HTTPStatus.OK)


@bp.route('/logs', methods=['GET'])
@requires_api_auth
def get_logs():
    '''
        Endpoint used to fetch the logging file
    '''
    log_file = os.path.join(current_app.root_path, 'logs', 'logs.log')

    if log_file is None:
        current_app.logger.error(f'Failed to locate log file')
        current_app.logger.info(f'GET /logs - {HTTPStatus.BAD_REQUEST}')
        return APIErrorValue("Failed to fetch log file").json(HTTPStatus.BAD_REQUEST)

    try:
        logs_response = LogsValue(log_file)

    except Exception as error:
        current_app.logger.error(f'Failed to parse log file: {error}')
        current_app.logger.info(f'GET /logs - {HTTPStatus.INTERNAL_SERVER_ERROR}')
        return APIErrorValue("Log file doesnt exist").json(HTTPStatus.INTERNAL_SERVER_ERROR)

    current_app.logger.info(f'GET /logs - {HTTPStatus.OK}')
    return logs_response.json(HTTPStatus.OK)
