from app.database import db
from sqlalchemy import Column, String
from app.models.base_model import BaseModel


class Secretariats(BaseModel, db.Model):
    __tablename__ = 'secretariats'

    name = Column(String(100), nullable=False)
    location = Column(String(100), nullable=False)
    description = Column(String(300))
    opening_hours = Column(String(20))
    closing_hours = Column(String(20))

    def __repr__(self):
        return f'Name: {self.name}  |  Location: {self.location}'
