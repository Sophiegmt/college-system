'''
    __init__.py

    File that instanciates the blueprint for the secretariat API
'''
from flask import Blueprint

# initialize blueprint for the microservice api logic
bp = Blueprint('secretariat-api', __name__)

# import endpoints
from app.api import routes
