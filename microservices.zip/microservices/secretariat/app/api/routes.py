'''
    routes.py

    This file contains the endpoints of the rooms blueprint
'''
import os
from http import HTTPStatus
from flask import make_response, request, current_app, send_file
from app.api import bp
# Data
from app.models.secretariats import Secretariats
# Services
from app.services.create_secretariat_service import CreateSecretariatService
from app.services.update_secretariat_service import UpdateSecretariatService
from app.services.delete_secretariat_service import DeleteSecretariatService
# Values
from app.values.secretariat_value import SecretariatValue
from app.values.secretariat_list_value import SecretariatListValue
from app.values.api_error_value import APIErrorValue
from app.values.logs_value import LogsValue
# Auth decorators
from app.decorators.auth_decorator import requires_api_auth, requires_admin_auth



@bp.route("/", methods=['GET'])
@requires_api_auth
def list_secretariats():
    '''
        Endpoint used to list all the secretariats
    '''
    secretariats = Secretariats.all()

    if len(secretariats) == 0 or secretariats is None:
        current_app.logger.info(f'GET /secretariats - {HTTPStatus.BAD_REQUEST}')
        return APIErrorValue('Secretary data is empty').json(HTTPStatus.BAD_REQUEST)

    current_app.logger.info(f'GET /secretariats - {HTTPStatus.OK}')
    return SecretariatListValue(secretariats).json(HTTPStatus.OK)


@bp.route("/<string:secretariat_external_id>", methods=['GET'])
@requires_api_auth
def get_secretariat(secretariat_external_id):
    '''
        Endpoint used to retrieve a specific
        secretariat by id
    '''
    secretariat = Secretariats.get_by(external_id=secretariat_external_id)

    if secretariat is None:
        current_app.logger.info(f'GET /secretariats/ - {HTTPStatus.BAD_REQUEST}')
        return APIErrorValue('Secretary doesnt exist!').json(HTTPStatus.BAD_REQUEST)
    
    current_app.logger.info(f'GET /secretariats/ - {HTTPStatus.OK}')
    return SecretariatValue(secretariat).json(HTTPStatus.OK)


@bp.route("/", methods=['POST'])
@requires_admin_auth
def create_secretariat():
    '''
        Endpoint used to create a new secretariat
    '''
    data = request.form

    name = data.get('name', None)
    location = data.get('location', None)
    description = data.get('description', None)
    opening_hours = data.get('opening_hours', None)
    closing_hours = data.get('closing_hours', None)

    secretariat = CreateSecretariatService(
        name=name,
        location=location,
        description=description,
        opening_hours=opening_hours,
        closing_hours=closing_hours
    ).call()

    if not secretariat:
        current_app.logger.info(f'POST /secretariats - {HTTPStatus.INTERNAL_SERVER_ERROR}')
        return APIErrorValue('Failed to create new secretariat!').json(HTTPStatus.INTERNAL_SERVER_ERROR)
    
    current_app.logger.info(f'POST /secretariats - {HTTPStatus.OK}')
    return SecretariatValue(secretariat).json(HTTPStatus.OK)


@bp.route("/<string:secretariat_external_id>", methods=['PUT'])
@requires_admin_auth
def update_secretariat(secretariat_external_id):
    '''
        Endpoint used to update a specific
        secretariat by id
    '''
    secretariat = Secretariats.get_by(external_id=secretariat_external_id)

    if not secretariat:
        current_app.logger.info(f'PUT /secretariats/ - {HTTPStatus.BAD_REQUEST}')
        return APIErrorValue('Secretary doesnt exist!').json(HTTPStatus.BAD_REQUEST)

    data = request.form

    updated_secretariat = UpdateSecretariatService(
        secretariat=secretariat,
        kwargs=data
    ).call()

    if not updated_secretariat:
        current_app.logger.info(f'PUT /secretariats/ - {HTTPStatus.INTERNAL_SERVER_ERROR}')
        return APIErrorValue('Failed to update secretariat!').json(HTTPStatus.INTERNAL_SERVER_ERROR)

    current_app.logger.info(f'PUT /secretariats/ - {HTTPStatus.OK}')
    return SecretariatValue(updated_secretariat).json(HTTPStatus.OK)


@bp.route("/<string:secretariat_external_id>", methods=['DELETE'])
@requires_admin_auth
def delete_secretariat(secretariat_external_id):
    '''
        Endpoint used to delete a specific
        secretariat by id
    '''
    secretariat = Secretariats.get_by(external_id=secretariat_external_id)

    if not secretariat:
        current_app.logger.info(f'DELETE /secretariats/ - {HTTPStatus.BAD_REQUEST}')
        return APIErrorValue('Secretary doesnt exist!').json(HTTPStatus.BAD_REQUEST)

    if not DeleteSecretariatService(secretariat=secretariat).call():
        current_app.logger.info(f'DELETE /secretariats/ - {HTTPStatus.INTERNAL_SERVER_ERROR}')
        return APIErrorValue('Failed to delete secretariat!').json(HTTPStatus.INTERNAL_SERVER_ERROR)

    response = {'message': 'Sucessfully deleted secretariat.'}
    current_app.logger.info(f'DELETE /secretariats/ - {HTTPStatus.OK}')
    return make_response(response, HTTPStatus.OK)


@bp.route('/logs', methods=['GET'])
@requires_api_auth
def get_logs():
    '''
        Endpoint used to fetch the logging file
    '''
    log_file = os.path.join(current_app.root_path, 'logs', 'logs.log')

    if log_file is None:
        current_app.logger.error(f'Failed to locate log file')
        current_app.logger.info(f'GET /logs - {HTTPStatus.BAD_REQUEST}')
        return APIErrorValue("Failed to fetch log file").json(HTTPStatus.BAD_REQUEST)

    try:
        logs_response = LogsValue(log_file)

    except Exception as error:
        current_app.logger.error(f'Failed to parse log file: {error}')
        current_app.logger.info(f'GET /logs - {HTTPStatus.INTERNAL_SERVER_ERROR}')
        return APIErrorValue("Log file doesnt exist").json(HTTPStatus.INTERNAL_SERVER_ERROR)

    current_app.logger.info(f'GET /logs - {HTTPStatus.OK}')
    return logs_response.json(HTTPStatus.OK)
