from flask import current_app
from app.models.secretariats import Secretariats
from app.database import db_session


class DeleteSecretariatService():

    def __init__(self, secretariat: Secretariats):
        self.secretariat = secretariat

    def call(self):
        try:
            db_session.delete(self.secretariat)
            db_session.commit()

        except Exception as error:
            db_session.rollback()
            current_app.logger.error(f'Failed to delete a secretariat: {error}')
            return False

        current_app.logger.info('Deleted a secretariat.')
        return True
