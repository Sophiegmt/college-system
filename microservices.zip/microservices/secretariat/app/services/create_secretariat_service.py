from app.models.secretariats import Secretariats
from flask import current_app
from typing import Optional


class CreateSecretariatService():
    '''
        Services that creates a new secretariat instance
        and inserts it in the picke file
    '''

    def __init__(self, location, name, description, opening_hours, closing_hours):
        self.location = location
        self.name = name
        self.description = description
        self.opening_hours = opening_hours
        self.closing_hours = closing_hours

    def call(self) -> Optional[Secretariats]:
        try:
            secretariat = Secretariats.create(
                name=self.name,
                description=self.description,
                location=self.location,
                opening_hours=self.opening_hours,
                closing_hours=self.closing_hours
            )

        except Exception as error:
            current_app.logger.error(f'Failed to create secretariat: {error}')
            return None

        current_app.logger.info(f'Created a new secretariat: {self.name}')
        return secretariat
