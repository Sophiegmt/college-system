from typing import Dict, Optional
from flask import current_app
from app.models.secretariats import Secretariats


class UpdateSecretariatService():

    def __init__(self, secretariat: Secretariats, kwargs: Dict):
        self.secretariat = secretariat
        self.kwargs = kwargs

    def call(self) -> Optional[Secretariats]:

        try:
            secretariat = self.secretariat.update(**self.kwargs)

        except Exception as error:
            current_app.logger.error(f'Failed to update secretariat: {error}')
            return None

        current_app.logger.info(f'Secretariat updated sucessfuly: {secretariat.name}')
        return secretariat
