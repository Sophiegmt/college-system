""" Creates the secretariats table

Revision ID: 7801580104ea
Revises: 
Create Date: 2019-12-04 17:48:27.150057

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql
import sqlalchemy_utils

# revision identifiers, used by Alembic.
revision = '7801580104ea'
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    op.create_table('secretariats',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('created_at', postgresql.TIMESTAMP(), nullable=True),
    sa.Column('updated_at', postgresql.TIMESTAMP(), nullable=True),
    sa.Column('external_id', sqlalchemy_utils.types.uuid.UUIDType(), nullable=True),
    sa.Column('name', sa.String(length=100), nullable=False),
    sa.Column('location', sa.String(length=100), nullable=False),
    sa.Column('description', sa.String(length=300), nullable=True),
    sa.Column('opening_hours', sa.String(length=20), nullable=True),
    sa.Column('closing_hours', sa.String(length=10), nullable=True),
    sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_secretariats_external_id'), 'secretariats', ['external_id'], unique=False)


def downgrade():
    op.drop_index(op.f('ix_secretariats_external_id'), table_name='secretariats')
    op.drop_table('secretariats')
