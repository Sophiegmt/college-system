from app.values.value_composite import ValueComposite
from app.values.secretariat_value import SecretariatValue


class SecretariatListValue(ValueComposite):
    def __init__(self, secretariats):
        super(SecretariatListValue, self).initialize({})

        secretariats_list = []
        for secretariat in secretariats:
            secretariats_list.append(SecretariatValue(secretariat).to_dict())

        self.serialize_with(secretariats=secretariats_list)
