import os
from flask import request, current_app, Response
from functools import wraps
import base64


def requires_api_auth(function):
    @wraps(function)
    def decorated(*args, **kwargs):
        if os.environ.get('AUTHENTICATION', 'True') == 'False':
            return function(*args, **kwargs)

        http_auth = request.environ.get('HTTP_AUTHORIZATION')

        if http_auth:
            auth_type, data = http_auth.split(' ', 1)

            if auth_type == 'Basic':
                try: 
                    username, api_key = data.split(':', 1)

                    if username == os.environ.get('API_USERNAME') and api_key == os.environ.get('API_KEY'):
                        return function(*args, **kwargs)
                except:
                    pass
            
            auth_string = os.environ.get('API_USERNAME') + ':' + os.environ.get('API_KEY')
            auth_bytes = auth_string.encode("utf-8")

            if data.encode("utf-8") == base64.b64encode(auth_bytes):
                return function(*args, **kwargs)

        current_app.logger.warning('Client failed to authenticate!')
        return Response("Access denied", status=401)
    return decorated


def requires_admin_auth(function):
    @wraps(function)
    def decorated(*args, **kwargs):
        if os.environ.get('AUTHENTICATION', 'True') == 'False':
            return function(*args, **kwargs)

        http_auth = request.environ.get('HTTP_AUTHORIZATION')

        if http_auth:
            auth_type, data = http_auth.split(' ', 1)

            if auth_type == 'Basic':
                try: 
                    username, api_key = data.split(':', 1)

                    if username == os.environ.get('API_ADMIN_USERNAME') and api_key == os.environ.get('API_ADMIN_KEY'):
                        return function(*args, **kwargs)
                except:
                    pass
            
            auth_string = os.environ.get('API_ADMIN_USERNAME') + ':' + os.environ.get('API_ADMIN_KEY')
            auth_bytes = auth_string.encode("utf-8")

            if data.encode("utf-8") == base64.b64encode(auth_bytes):
                return function(*args, **kwargs)

        current_app.logger.warning('Client failed to authenticate!')
        return Response("Access denied", status=401)
    return decorated
