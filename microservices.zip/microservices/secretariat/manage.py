import os
from flask_script import Manager, Server, Command
from flask_migrate import Migrate, MigrateCommand
from app import create_app, db


app = create_app(os.getenv('APP_ENVIRONMENT'))
manager = Manager(app)
current_path = os.path.dirname(os.path.realpath(__file__))
migrations_dir = os.path.join(current_path, 'app', 'database', 'migrations')
migrate = Migrate(app, db, directory=migrations_dir)



class Test(Command):
    '''
        Run tests using pytest
    '''

    def run(self):
        ''' Run tests using pytest '''
        import pytest
        pytest_args = ['--verbose']
        pytest_runner = pytest.main(pytest_args)
        exit(pytest_runner)


@manager.shell
def shell_context():
    import pprint
    import flask

    context = dict(pprint=pprint.pprint)
    context.update(vars(flask))
    context.update(vars(app))

    return context


if __name__ == '__main__':
    manager.add_command('db', MigrateCommand)
    manager.add_command('runserver', Server('0.0.0.0', port=8004))
    manager.add_command('test', Test)
    manager.run()
