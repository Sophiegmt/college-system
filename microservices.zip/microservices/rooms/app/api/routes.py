'''
    routes.py

    This file contains the endpoints of the rooms blueprint
'''
import os
from http import HTTPStatus
from flask import make_response, jsonify, current_app
from app.api import bp
# Services
from app.services.request_fenix_data_service import RequestFenixDataService
# Values
from app.values.api_error_value import APIErrorValue
from app.values.logs_value import LogsValue
# Auth decorators
from app.decorators.auth_decorator import requires_api_auth
from app.values.room_value import RoomValue



@bp.route("/", methods=['GET'])
@requires_api_auth
def get_spaces_data():
    '''
        Endpoint used to request the rooms data
        from Técnico API
    '''
    try:
        space_data = RequestFenixDataService().call()

    except Exception:
        current_app.logger.info(f'GET /spaces - {HTTPStatus.SERVICE_UNAVAILABLE}')
        return APIErrorValue('Failed to query Fenix').json(HTTPStatus.SERVICE_UNAVAILABLE)

    data_json = jsonify(space_data.json())
    current_app.logger.info(f'GET /spaces - {HTTPStatus.OK}')
    return make_response(data_json, HTTPStatus.OK)


@bp.route("/<string:space_id>", methods=['GET'])
@requires_api_auth
def get_spaces_data_by_id(space_id):
    '''
        Endpoint used to request the rooms data
        from Técnico API, filtering by a specific
        space id.
    '''
    try:
        space_data = RequestFenixDataService(space_id=space_id).call()

    except Exception:
        current_app.logger.info(f'GET /spaces/ - {HTTPStatus.SERVICE_UNAVAILABLE}')
        return APIErrorValue('Failed to query Fenix').json(HTTPStatus.SERVICE_UNAVAILABLE)

    data_json = space_data.json()
    current_app.logger.info(f'GET /spaces/ - {HTTPStatus.OK}')
    return RoomValue(data_json).json(HTTPStatus.OK)


@bp.route('/logs', methods=['GET'])
@requires_api_auth
def get_logs():
    '''
        Endpoint used to fetch the logging file
    '''
    log_file = os.path.join(current_app.root_path, 'logs', 'logs.log')

    if log_file is None:
        current_app.logger.error(f'Failed to locate log file')
        current_app.logger.info(f'GET /logs - {HTTPStatus.BAD_REQUEST}')
        return APIErrorValue("Failed to fetch log file").json(HTTPStatus.BAD_REQUEST)

    try:
        logs_response = LogsValue(log_file)

    except Exception as error:
        current_app.logger.error(f'Failed to parse log file: {error}')
        current_app.logger.info(f'GET /logs - {HTTPStatus.INTERNAL_SERVER_ERROR}')
        return APIErrorValue("Log file doesnt exist").json(HTTPStatus.INTERNAL_SERVER_ERROR)

    current_app.logger.info(f'GET /logs - {HTTPStatus.OK}')
    return logs_response.json(HTTPStatus.OK)
