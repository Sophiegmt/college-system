'''
    __init__.py

    File that instanciates the blueprint for the rooms API
'''
from flask import Blueprint

# initialize blueprint for the microservice api logic
bp = Blueprint('rooms-api', __name__)

# import endpoints
from app.api import routes
