'''
    request_fenix_data_service.py

    This file contains the service used to request
    data from the Técnico API regarding the rooms
'''
import os
from flask import current_app
import requests


class RequestFenixDataService():
    '''
        Service used to request canteen data from Técnico API

        Parameters:
        - url: the base url of the API
        - timeout: time limit, in seconds, to receive a response
                    from the API

        Returns:
        - response: data from Técnico api
    '''

    def __init__(self, space_id=None):
        self.url = os.getenv('TECNICO_API_URL') + '/spaces'
        self.timeout = int(os.getenv('TECNICO_API_TIMEOUT'))
        self.space_id = space_id

    def call(self):
        if self.space_id:
            self.url = self.url + f'/{self.space_id}'

        try:
            response = requests.get(self.url, timeout=self.timeout)

            # if the answer is not 200, raise an exception
            response.raise_for_status()

        # if the request fails, raise the exception and log it
        except Exception as error:
            current_app.logger.error(f'Failed to request Fenix data: {error}')
            raise
        
        current_app.logger.info(f'Sucessfully requested data from Tecnico API')
        return response
