from app.values.value_composite import ValueComposite


class RoomValue(ValueComposite):
    def __init__(self, room_info):
        super(RoomValue, self).initialize({})

        room = {}

        room['type'] = room_info.get('type', None)
        room['id'] = room_info.get('id', None)
        name = room_info.get('name', None)
        room['name'] = name.encode('utf-8')

        if room_info.get('topLevelSpace', None):
            room['topLevelSpace'] = {
                'name': room_info['topLevelSpace']['name'],
                'type': room_info['topLevelSpace']['type']
            }

        if room_info.get('topLevelSpace', None):
            room['description'] = room_info['description']

        if room_info.get('capacity', None):
            room['capacity'] = {
                'normal': room_info['capacity']['normal'],
                'exam': room_info['capacity']['exam']
            }

        if room_info.get('events', None):
            event_list = []
            for event in room_info.get('events', None):
                event_info = {
                    'type': event.get('type', None),
                    'start': event.get('start', None),
                    'end': event.get('end', None),
                    'weekday': event.get('weekday', None),
                    'day': event.get('day', None),
                    'info' : event.get('info', None),
                }
                if event.get('period', None):
                    event_info['period'] = {
                        'start': event['period']['start'],
                        'end': event['period']['end']
                    }
                if event.get('course', None):
                    event_info['course'] = {
                        'name': event['course']['name'],
                        'url': event['course']['url'],
                        'academicTerm': event['course']['name']
                    }
                event_list.append(event_info)

            room['events']=event_list

        self.serialize_with(room=room)