import os
import base64
from flask import session, redirect, current_app

# handlers
from client.handlers.tecnico_client_handler import TecnicoClientHandler


class AuthHandler(object):
    
    @staticmethod
    def login_tecnico(fenix_client, fenix_auth_code):
        if fenix_auth_code is not None:            
            user = TecnicoClientHandler.get_user(fenix_client, fenix_auth_code)
            person = TecnicoClientHandler.get_person(fenix_client, user)

            name = person['name']
            username = person['username']

            session['NAME'] = person['name']
            session['USERNAME'] = person['username']
            session['ROLE'] = 'tecnico'
            session['AUTHENTICATED'] = True

            imgdata = base64.b64decode(person['photo']['data'])
            filename = f'client/static/user/photos/{username}.jpg'
            with open(filename, 'wb') as f:
                f.write(imgdata)

            current_app.logger.info(f"Student authenticated! ist_id: {name}")
            return True

        else:
            return False, "Failed to fetch Fenix_Auth_Code"

    @staticmethod
    def login_admin(username, password):
        if username != os.getenv('ADMIN_USERNAME') or password != os.getenv('ADMIN_PASSWORD'):
            current_app.logger.info('Invalid admin credentials inserted!')
            return False

        session['ROLE'] = 'admin'
        session['AUTHENTICATED'] = True

        current_app.logger.info('Admin authenticated!')
        return True

    @staticmethod
    def logout():
        try:
            role = session.get('ROLE', None)

            if role == 'tecnico':
                session.pop('NAME')
                session.pop('USERNAME')

            session.pop('ROLE')
            session.pop('AUTHENTICATED')

        except Exception as error:
            current_app.logger.error(f'Failed to logout user: {error}')
            return False

        return True

