'''
    auth_decorators.py

    This file contains decorators used to wrap python methods
    This decorators apply the need for authentication to any request
    that goes to the endpoint in question
'''
import os
from functools import wraps
from flask import session, redirect, url_for


def require_tecnico_login(func):
    '''
        This decorator is used to require the user
        to be logged in and tecnico student.
        The session cookie is used to check the presence
        of the required role

        Requirements:
        - session variable AUTHENTICATED == True
        - session variable ROLE == tecnico
    '''
    @wraps(func)
    def check_tecnico_login(*args, **kwargs):
        if os.environ.get('AUTHENTICATION', 'True') == 'False':
            return func(*args, **kwargs)

        try:
            authenticated = session['AUTHENTICATED']
            role = session['ROLE']
            name = session['NAME']
            username = session['USERNAME']
        except:
            return redirect(url_for('user.login'))

        if not authenticated or role != 'tecnico':
            return redirect(url_for('user.login'))

        return func(*args, **kwargs)
    return check_tecnico_login


def require_admin_login(func):
    '''
        This decorator is used to require the user
        to be logged in and admin.
        The session cookie is used to check the presence
        of the required role

        Requirements:
        - session variable AUTHENTICATED == True
        - session variable ROLE == admin
    '''
    @wraps(func)
    def check_admin_login(*args, **kwargs):
        if os.environ.get('AUTHENTICATION', 'True') == 'False':
            return func(*args, **kwargs)

        try:
            authenticated = session['AUTHENTICATED']
            role = session['ROLE']
        except:
            return redirect(url_for('admin.login_form'))

        if not authenticated or role != 'admin':
            return redirect(url_for('admin.login_form'))

        return func(*args, **kwargs)
    return check_admin_login
