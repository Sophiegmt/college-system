'''
    routes.py

    This file contains the endpoints of the canteen blueprint
'''
import os
from http import HTTPStatus
from flask import render_template, jsonify, current_app
from .. import bp
from client.services.request_backend_data_service import RequestBackendDataService
from client.decorators.auth_decorators import require_admin_login


@bp.route("/logs", methods=['GET'])
@require_admin_login
def logged_apps():
    '''
        Endpoint used to request the available services
    '''
    uri = '/admin/services'
    username = current_app.config.get('ADMIN_BACKEND_USERNAME')
    password = current_app.config.get('ADMIN_BACKEND_PASSWORD')

    response = RequestBackendDataService(
        uri=uri,
        username=username,
        password=password
    ).call()

    print(response.json())

    if not response:
        services = None
    else:
        services = response.json()['services']

    backend = {
        'name': 'Backend API',
        'service_name': 'backend',
    }

    services.append(backend)
    
    return render_template('admin/logs_menu.html', services=services) # envia a lista dos secretariados


@bp.route("/logs/<string:service>", methods=['GET'])
@require_admin_login
def get_logs(service):
    '''
        Endpoint used to request logs data
    '''
    uri = f'/admin/logs/{service}'
    username = current_app.config.get('ADMIN_BACKEND_USERNAME')
    password = current_app.config.get('ADMIN_BACKEND_PASSWORD')

    response = RequestBackendDataService(
        uri=uri,
        username=username,
        password=password
    ).call()

    if not response:
        logs = None
    else:
        logs = response.json()['list']

    return render_template('admin/service_logs.html', logs=logs, service=service) # envia a lista dos secretariados
