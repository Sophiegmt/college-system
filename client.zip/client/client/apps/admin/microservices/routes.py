'''
    routes.py

    This file contains the endpoints of the canteen blueprint
'''
from flask import render_template, request, current_app, redirect, url_for
from .. import bp
from client.services.request_backend_data_service import RequestBackendDataService
from client.services.post_backend_data_service import PostBackendDataService
from client.decorators.auth_decorators import require_admin_login
from client.services.update_backend_data_service import UpdateBackendDataService

@bp.route("/microservices", methods=['GET'])
@require_admin_login
def get_microservices_dashboard():
    '''
        Endpoint used to list all the existant microservices
    '''
    uri = '/admin/services'
    username = current_app.config.get('ADMIN_BACKEND_USERNAME')
    password = current_app.config.get('ADMIN_BACKEND_PASSWORD')

    response = RequestBackendDataService(
        uri=uri,
        username=username,
        password=password
    ).call()

    if not response:
        microservices = None
    else:
        microservices = response.json()['services']

    return render_template('/admin/microservices_dashboard.html', microservices=microservices) 


@bp.route("/microservices/<string:service_name>", methods=['GET'])
@require_admin_login
def get_microservice_info(service_name):
    '''
        Endpoint used to the existant microservice with ID=microservice_id
    '''
    uri = f'/admin/services/{service_name}'
    username = current_app.config.get('ADMIN_BACKEND_USERNAME')
    password = current_app.config.get('ADMIN_BACKEND_PASSWORD')

    response = RequestBackendDataService(
        uri=uri,
        username=username,
        password=password
    ).call()

    if not response:
        microservice = None
    else:
        microservice = response.json()

    return render_template('/admin/microservice_form.html', microservice=microservice) 

@bp.route("/microservices/<string:service_name>", methods=['POST'])
@require_admin_login
def edit_microservice_dashboard(service_name):
    '''
        Endpoint used to get the template used to edit a 
        single microservice data.
    '''
    data = {
        'name': request.form.get('name'),
        'service_name': request.form.get('service_name'),
        'endpoint': request.form.get('endpoint')
    }

    uri = f'/admin/services/{service_name}'
    username = current_app.config.get('ADMIN_BACKEND_USERNAME')
    password = current_app.config.get('ADMIN_BACKEND_PASSWORD')

    UpdateBackendDataService(
        uri=uri,
        data=data,
        username=username,
        password=password
    ).call()
    
    return redirect(url_for('admin.get_microservices_dashboard'))


@bp.route("/microservices/new", methods=['GET'])
@require_admin_login
def new_microservice_form():
    '''
        Endpoint used to get the template used to edit a 
        single microservice data.
    '''
    return render_template('/admin/new_microservice_form.html')


@bp.route("/microservices/new", methods=['POST'])
@require_admin_login
def add_new_microservice():
    '''
        Endpoint used to get the template used to edit a 
        single secretariat data.
    '''
    data = {
        'name': request.form.get('name'),
        'service_name': request.form.get('service_name'),
        'endpoint': request.form.get('endpoint')
    }

    uri = f'/admin/services'
    username = current_app.config.get('ADMIN_BACKEND_USERNAME')
    password = current_app.config.get('ADMIN_BACKEND_PASSWORD')

    PostBackendDataService(
        uri=uri,
        data=data,
        username=username,
        password=password
    ).call()

    return redirect(url_for('admin.get_microservices_dashboard'))
