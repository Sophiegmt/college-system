'''
    __init__.py

    File that instanciates the blueprint for the admin API
'''
from flask import Blueprint

# initialize blueprint for the admin api logic
bp = Blueprint('admin', __name__)

# import endpoints
from client.apps.admin import routes
from client.apps.admin.auth import routes
from client.apps.admin.logs import routes
from client.apps.admin.secretariat import routes
from client.apps.admin.microservices import routes
