'''
    routes.py

    This file contains the endpoints of the admin blueprint
'''
from flask import render_template
from client.apps.admin import bp
from client.decorators.auth_decorators import require_admin_login


@bp.route("/", methods=['GET'])
@require_admin_login
def index():
    '''
        Endpoint used to get the admin dashboard
    '''
    return render_template('/admin/menu.html')
