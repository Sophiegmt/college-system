'''
    routes.py

    This file contains the endpoints of the canteen blueprint
'''
from flask import render_template, request, current_app, redirect, url_for
from .. import bp
from client.services.request_backend_data_service import RequestBackendDataService
from client.services.post_backend_data_service import PostBackendDataService
from client.decorators.auth_decorators import require_admin_login
from client.services.update_backend_data_service import UpdateBackendDataService

@bp.route("/secretariats", methods=['GET'])
@require_admin_login
def get_secretariats_dashboard():
    '''
        Endpoint used to list all the existant secretariats
    '''
    uri = '/admin/secretariats'
    username = current_app.config.get('ADMIN_BACKEND_USERNAME')
    password = current_app.config.get('ADMIN_BACKEND_PASSWORD')

    response = RequestBackendDataService(
        uri=uri,
        username=username,
        password=password
    ).call()

    if not response:
        secretariats = None
    else:
        secretariats = response.json()['secretariats']

    return render_template('/admin/secretariats_dashboard.html', secretariats=secretariats) # envia a lista dos secretariados


@bp.route("/secretariats/<string:secretariat_id>", methods=['GET'])
@require_admin_login
def get_secretariat_info(secretariat_id):
    '''
        Endpoint used to the existant secretariat with ID=secretariat_id
    '''
    uri = f'/admin/secretariats/{secretariat_id}'
    username = current_app.config.get('ADMIN_BACKEND_USERNAME')
    password = current_app.config.get('ADMIN_BACKEND_PASSWORD')

    response = RequestBackendDataService(
        uri=uri,
        username=username,
        password=password
    ).call()

    if not response:
        secretariat = None
    else:
        secretariat = response.json()

    return render_template('/admin/secretariat_form.html', secretariat=secretariat) # envia a lista dos secretariados


@bp.route("/secretariats/<string:secretariat_id>", methods=['POST'])
@require_admin_login
def edit_secretariat_dashboard(secretariat_id):
    '''
        Endpoint used to get the template used to edit a 
        single secretariat data.
    '''
    data = {
        'name': request.form.get('name'),
        'location': request.form.get('location'),
        'description': request.form.get('description'),
        'opening_hours': request.form.get('opening_hours'),
        'closing_hours': request.form.get('closing_hours')
    }

    uri = f'/admin/secretariats/{secretariat_id}'
    username = current_app.config.get('ADMIN_BACKEND_USERNAME')
    password = current_app.config.get('ADMIN_BACKEND_PASSWORD')

    response = UpdateBackendDataService(
        uri=uri,
        data=data,
        username=username,
        password=password
    ).call()

    if not response:
        secretariat = None
    else:
        secretariat = response.json()

    return redirect(url_for('admin.get_secretariats_dashboard'))


@bp.route("/secretariats/new", methods=['GET'])
@require_admin_login
def new_secretariat_form():
    '''
        Endpoint used to get the template used to edit a 
        single secretariat data.
    '''
    return render_template('/admin/new_secretariat_form.html')


@bp.route("/secretariats/new", methods=['POST'])
@require_admin_login
def add_new_secretariat():
    '''
        Endpoint used to get the template used to edit a 
        single secretariat data.
    '''
    data = {
        'name': request.form.get('name'),
        'location': request.form.get('location'),
        'description': request.form.get('description'),
        'opening_hours': request.form.get('opening_hours'),
        'closing_hours': request.form.get('closing_hours')
    }

    uri = f'/admin/secretariats'
    username = current_app.config.get('ADMIN_BACKEND_USERNAME')
    password = current_app.config.get('ADMIN_BACKEND_PASSWORD')

    PostBackendDataService(
        uri=uri,
        data=data,
        username=username,
        password=password
    ).call()

    return redirect(url_for('admin.get_secretariats_dashboard'))
