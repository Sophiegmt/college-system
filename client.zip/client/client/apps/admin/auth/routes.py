'''
    routes.py

    This file contains the endpoints of the canteen blueprint
'''
from flask import url_for, request, redirect, session, render_template
from client.apps.admin import bp

from client.handlers.auth_handler import AuthHandler


@bp.route("/login", methods=['GET'])
def login_form():
    '''
        Endpoint used to request login the admin
    '''
    if session.get('AUTHENTICATED') and session.get('ROLE') == 'admin':
        return redirect(url_for('admin.index'))

    return render_template('/admin/login.html')


@bp.route("/login", methods=['POST'])
def login_admin():
    '''
        Endpoint used to request login the admin
    '''
    username = request.form.get('username')
    password = request.form.get('password')

    if AuthHandler.login_admin(username, password) is True:
        return redirect(url_for('admin.index'))

    return redirect(url_for('admin.login_form'))


@bp.route("/logout", methods=['GET'])
def logout_admin():
    '''
        Endpoint used to end the admin session and logout
    '''
    AuthHandler.logout()
    return redirect(url_for('admin.login_form'))
