'''
    routes.py

    This file contains the endpoints related to user authentication
'''
from flask import redirect, url_for, request, current_app, session
from client.apps.user import bp
from client.handlers.tecnico_client_handler import TecnicoClientHandler
from client.handlers.auth_handler import AuthHandler

fenix_client = None


@bp.route('/login', methods=['GET'])
def login():
    '''
        Redirects the user to the Fenix login page
    '''
    global fenix_client
    fenix_client = TecnicoClientHandler.create_client()

    url = TecnicoClientHandler.get_authentication_url(fenix_client)
    return redirect(url, code=302)


@bp.route('/redirect_uri', methods=['GET'])
def redirect_uri():
    '''
        Fenix API will answer to this endpoint
        with the authentication response
    '''
    if request.args.get('error') == "access_denied":
        return redirect(url_for('/'))

    fenix_auth_code = request.args.get('code')

    global fenix_client

    if AuthHandler.login_tecnico(fenix_client, fenix_auth_code) is True:
        return redirect(url_for('user.index'))

    else:
        return redirect(url_for('user.login'))


@bp.route('/logout', methods=['GET'])
def logout():
    AuthHandler.logout()
    return redirect(url_for('user.login'))
