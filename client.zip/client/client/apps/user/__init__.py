'''
    __init__.py

    File that instanciates the blueprint for the user API
'''
from flask import Blueprint, current_app

# initialize blueprint for the user api logic
bp = Blueprint('user', __name__)


# import endpoints
from . import routes
from client.apps.user.auth import routes
from client.apps.user.canteen import routes
from client.apps.user.rooms import routes
from client.apps.user.secretariats import routes
from client.apps.user.verification import routes
