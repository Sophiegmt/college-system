'''
    routes.py

    This file contains the endpoints of the user blueprint
'''
from flask import render_template, session
from client.apps.user import bp
from client.decorators.auth_decorators import require_tecnico_login


# Student login
@bp.route('/', methods=['GET'])
@require_tecnico_login
def index():
    name = session.get('NAME', None)
    username = session.get('USERNAME', None)
    photo_path = f'static/user/photos/{username}.jpg'

    return render_template('/user/menu.html', name=name, username=username, photo_path=photo_path)


@bp.route('/qrcode')
@require_tecnico_login
def get_qrcode():
    return render_template('/user/qr_code.html')
