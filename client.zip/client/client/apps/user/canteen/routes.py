'''
    routes.py

    This file contains the endpoints of the canteen blueprint
'''
from flask import render_template, current_app
from .. import bp
from client.services.request_backend_data_service import RequestBackendDataService


@bp.route("/canteen", methods=['GET'])
def get_canteen_dashboard():
    '''
        Endpoint used to list all the existant canteen meals
    '''
    uri = f'/services/canteen'
    username = current_app.config.get('CLIENT_BACKEND_USERNAME')
    password = current_app.config.get('CLIENT_BACKEND_PASSWORD')

    response = RequestBackendDataService(
        uri=uri,
        username=username,
        password=password
    ).call()

    if not response:
        canteens = None
    else:
        canteens = response.json()

    return render_template('/user/canteen.html', canteens=canteens)


@bp.route("/canteen/<string:canteen_date>", methods=['GET'])
def get_canteen_info(canteen_date):
    '''
        Endpoint used to the existant secretariat with ID=secretariat_id
    '''
    uri = f'/services/canteen/{canteen_date}'
    username = current_app.config.get('CLIENT_BACKEND_USERNAME')
    password = current_app.config.get('CLIENT_BACKEND_PASSWORD')
    
    response = RequestBackendDataService(
        uri=uri,
        username=username,
        password=password
    ).call()

    if not response:
        return render_template('/user/canteen.html', canteens=None)
    else:
        canteen = response.json()
    
    return render_template('/user/canteen_day.html', canteens=canteen) # envia a lista do dia da canteen
