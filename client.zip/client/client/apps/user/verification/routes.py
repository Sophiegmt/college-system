from flask import render_template, current_app, session, redirect, url_for
from http import HTTPStatus
from .. import bp
from client.services.request_backend_data_service import RequestBackendDataService
from client.services.post_backend_data_service import PostBackendDataService
from client.decorators.auth_decorators import require_tecnico_login
from flask_socketio import emit
from client import socketio


@bp.route('/verification', methods=['GET'])
@require_tecnico_login
def get_verification_dashboard():
    username = session.get('USERNAME', None)
    name = session.get('NAME', None)

    # try to get user
    uri = f'/users/{username}'
    auth_username = current_app.config.get('CLIENT_BACKEND_USERNAME')
    auth_password = current_app.config.get('CLIENT_BACKEND_PASSWORD')
    response = RequestBackendDataService(
        uri=uri,
        username=auth_username,
        password=auth_password
    ).call()

    if not response:
        uri = f'/users/'
        data = {
            'fullname': name,
            'username': username
        }
        response = PostBackendDataService(
            uri=uri,
            username=auth_username,
            password=auth_password,
            data=data
        ).call()

    if not response:
        return render_template('user/verification.html', code=None, username=None)

    code = response.json().get('code', None)
    return render_template('user/verification.html', code=code, username=username)


@bp.route('/verification', methods=['POST'])
@require_tecnico_login
def generate_code():
    username = session.get('USERNAME', None)
    uri = f'/users/{username}/code'
    username = current_app.config.get('CLIENT_BACKEND_USERNAME')
    password = current_app.config.get('CLIENT_BACKEND_PASSWORD')

    response = PostBackendDataService(
        uri=uri,
        username=username,
        password=password
    ).call()
    return redirect(url_for('user.get_verification_dashboard'))


def messageReceived(methods=['GET', 'POST']):
    print('message was received!!!')


@socketio.on('my event')
def handle_my_custom_event(json, methods=['GET', 'POST']):
    uri = '/users/code'
    username = current_app.config.get('CLIENT_BACKEND_USERNAME')
    password = current_app.config.get('CLIENT_BACKEND_PASSWORD')

    code = json.get('message', None)
    verifier = session.get('USERNAME', None)

    if code:
        data = {
            'verifier': verifier,
            'code': json['message']
        }

        response = PostBackendDataService(
            uri=uri,
            data=data,
            username=username,
            password=password
        ).call()

        if response:
            verifier_name = session['NAME']
            verifier_username = session['USERNAME']
            verifier_photo = f'static/user/photos/{verifier_username}.jpg'

            match_name = response.json()['fullname']
            match_username = response.json()['username']
            match_photo = f'static/user/photos/{match_username}.jpg'

            verification_data = {
                'verifier_name': verifier_name,
                'verifier_username': verifier_username,
                'verifier_photo': verifier_photo,
                'match_name': match_name,
                'match_username': match_username,
                'match_photo': match_photo
            }

            socketio.emit('my response', verification_data, callback=messageReceived)
