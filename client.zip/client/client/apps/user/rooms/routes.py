'''
    routes.py

    This file contains the endpoints of the rooms
'''
from flask import render_template, current_app
from .. import bp
from client.services.request_backend_data_service import RequestBackendDataService


@bp.route("/room/<string:room_id>", methods=['GET'])
def get_room_info(room_id):
    '''
        Endpoint used to the existant secretariat with ID=secretariat_id
    '''
    uri = f'/services/rooms/{room_id}'
    username = current_app.config.get('CLIENT_BACKEND_USERNAME')
    password = current_app.config.get('CLIENT_BACKEND_PASSWORD')

    response = RequestBackendDataService(
        uri=uri,
        username=username,
        password=password
    ).call()

    if not response:
        room = None
    else:
        room = response.json()['room']

    return render_template('/user/room.html', room=room) # envia a lista do dia da canteen
