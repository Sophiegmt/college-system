'''
    routes.py

    This file contains the endpoints of the canteen blueprint
'''
from flask import render_template, current_app
from .. import bp
from client.services.request_backend_data_service import RequestBackendDataService


@bp.route("/secretariats", methods=['GET'])
def list_secretariats():
    '''
        Endpoint used to list all the secretariats
    '''
    uri = '/services/secretariats'
    username = current_app.config.get('CLIENT_BACKEND_USERNAME')
    password = current_app.config.get('CLIENT_BACKEND_PASSWORD')

    
    response = RequestBackendDataService(
        uri=uri,
        username=username,
        password=password
    ).call()

    if not response:
        secretariats = None
    else:
        secretariats = response.json()['secretariats']

    return render_template('/user/secretariat.html', secretariats=secretariats)


@bp.route("/secretariats/<string:secretariat_id>", methods=['GET'])
def get__secretariat_info(secretariat_id):
    '''
        Endpoint used to the existant secretariat with ID=secretariat_id
    '''
    uri = f'/services/secretariats/{secretariat_id}'
    username = current_app.config.get('CLIENT_BACKEND_USERNAME')
    password = current_app.config.get('CLIENT_BACKEND_PASSWORD')

    response = RequestBackendDataService(
        uri=uri,
        username=username,
        password=password
    ).call()

    if not response:
        secretariat = None
    else:
        secretariat = response.json()['secretariats']

    return render_template('/user/secretariat.html', secretariats=secretariat)
