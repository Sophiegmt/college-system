'''
    request_backend_data_service.py

    This file contains the service used to request
    data from the Backend API
'''
import os
from flask import current_app
import requests


class RequestBackendDataService():
    '''
        Service used to request data from the Backend API

        Parameters:
        - endpoint: the endpoint of the API
        - timeout: time limit, in seconds, to receive a response
                    from the API

        Returns:
        - response: data from the api
    '''
    def __init__(self, uri, username, password):
        self.endpoint = current_app.config.get('BACKEND_API_URL') + uri
        self.timeout = int(os.getenv('REQUEST_TIMEOUT'))
        self.headers = {
            'Authorization': f'Basic {username}:{password}'
        }

    def call(self):
        try:
            response = requests.get(
                url=self.endpoint,
                headers=self.headers,
                timeout=self.timeout
            )

            # if the answer is not 200, raise an exception
            response.raise_for_status()

        # if the request fails, raise the exception and log it
        except Exception as error:
            current_app.logger.error(f'Failed to request data from the backend: {error}')
            return None

        return response
