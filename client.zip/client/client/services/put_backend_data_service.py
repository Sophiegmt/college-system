'''
    put_data_service.py

    This file contains the service used to make
    PUT requests to any URL
'''
from flask import current_app
import requests


class PutBackendDataService():
    '''
        Service used to make a request using a PUT method

        Parameters:
        - url: the base url of the API
        - timeout: time limit, in seconds, to receive a response
                    from the API
        - data: payload to send

        Returns:
        - response: data from the api
    '''

    def __init__(self, url, timeout, data):
        username = current_app.config.get('MICROSERVICES_USERNAME')
        password = current_app.config.get('MICROSERVICES_PASSWORD')

        self.url = url
        self.timeout = timeout
        self.data = data
        self.headers = {
            'Authorization': f'{username}:{password}'
        }

    def call(self):
        try:
            response = requests.put(
                url=self.url,
                data=self.data,
                headers=self.headers,
                timeout=self.timeout
            )

            # if the answer is not 200, raise an exception
            response.raise_for_status()

        # if the request fails, raise the exception and log it
        except Exception as error:
            current_app.logger.error(f'Failed to make PUT request: {error}')
            return None

        return response
