'''
    post_data_service.py

    This file contains the service used to make
    PUT requests to any URL
'''
import os
from flask import current_app
import requests


class PostBackendDataService():
    '''
        Service used to make a request using a POST method

        Parameters:
        - url: the base url of the API
        - timeout: time limit, in seconds, to receive a response
                    from the API
        - data: payload to send

        Returns:
        - response: data from the api
    '''

    def __init__(self, uri, username, password, data=None):
        self.endpoint = current_app.config.get('BACKEND_API_URL') + uri
        self.timeout = int(os.getenv('REQUEST_TIMEOUT'))
        self.data = data
        self.headers = {
            'Authorization': f'Basic {username}:{password}'
        }

    def call(self):
        try:
            response = requests.post(
                url=self.endpoint,
                data=self.data,
                headers=self.headers,
                timeout=self.timeout
            )

            # if the answer is not 200, raise an exception
            response.raise_for_status()

        # if the request fails, raise the exception and log it
        except Exception as error:
            current_app.logger.error(f'Failed to make POST request: {error}')
            return None

        return response
