from flask import current_app
import fenixedu


class CreateTecnicoClientService(object):

    @classmethod
    def __init__(self, fenix_config_file):
        self.fenix_config_file = fenix_config_file

    def call(self):
        try:
            config = fenixedu.FenixEduConfiguration.fromConfigFile(self.fenix_config_file)
            client = fenixedu.FenixEduClient(config)

        except Exception as error:
            current_app.logger.error(f'Failed to initialize Tecnico client: {error}')
            return None

        return client
        