'''
    __init__.py

    This file contains logic used to initialize the flask application
    and initialize the respective blueprints
'''
import logging
from logging.handlers import RotatingFileHandler
from flask import Flask
from config import config, Config
from flask_socketio import SocketIO
from flask_cors import CORS


socketio = SocketIO()


def configure_logging(app):
    '''
        Initializes the log handler that will save
        the logs to a permanent disk file
    '''
    log_handler = RotatingFileHandler('client/logs/logs.log', maxBytes=500*1024, backupCount=2)
    log_handler.setLevel(logging.INFO)
    log_handler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s: %(message)s'))
    app.logger.addHandler(log_handler)


def create_app(app_environment):
    '''
        This method creates and configures the
        Flask application according to an environment
    '''
    # creates the flask app
    app = Flask(__name__)

    # configure app according to environment
    app.config.from_object(config[app_environment])
    configure_logging(app)

    app.app_context().push()

    socketio.init_app(app)

    CORS(app)

    # initialize canteen blueprint
    from client.apps.admin import bp as admin_api_bp
    app.register_blueprint(admin_api_bp, url_prefix='/admin')

    from client.apps.user import bp as user_api_bp
    app.register_blueprint(user_api_bp)

    return app
