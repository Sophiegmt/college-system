import os
import logging
from logging.handlers import SysLogHandler
from os.path import join, dirname
from dotenv import load_dotenv


dotenv_path = join(dirname(__file__), '.env')
load_dotenv(dotenv_path)

class Config(object):
    '''
        Default configuration
    '''
    APP_ENVIRONMENT = os.environ.get('APP_ENVIRONMENT', 'development')
    SECRET_KEY = os.environ.get('SECRET_KEY')
    DEBUG = True
    TESTING = False

    REQUEST_TIMEOUT = int(os.environ.get('REQUEST_TIMEOUT'))

    MICROSERVICES_USERNAME = os.environ.get('MICROSERVICES_USERNAME')
    MICROSERVICES_PASSWORD = os.environ.get('MICROSERVICES_PASSWORD')

    MICROSERVICES_ADMIN_USERNAME = os.environ.get('MICROSERVICES_ADMIN_USERNAME')
    MICROSERVICES_ADMIN_PASSWORD = os.environ.get('MICROSERVICES_ADMIN_PASSWORD')

    @classmethod
    def init_app(cls, app):
        pass


class DevelopmentConfig(Config):
    '''
        Development configuration
    '''
    APP_ENVIRONMENT = 'development'
    DEBUG = True
    TESTING = True

    @classmethod
    def init_app(cls, app):
        super(DevelopmentConfig, cls).init_app(app)

        syslog_handler = SysLogHandler()
        syslog_handler.setLevel(logging.WARNING)
        app.logger.addHandler(syslog_handler)


class TestingConfig(Config):
    '''
        Testing configuration
    '''
    APP_ENVIRONMENT = 'testing'
    DEBUG = True
    TESTING = True
    PRESERVE_CONTEXT_ON_EXCEPTION = False

    @classmethod
    def init_app(cls, app):
        super(TestingConfig, cls).init_app(app)

        syslog_handler = SysLogHandler()
        syslog_handler.setLevel(logging.WARNING)
        app.logger.addHandler(syslog_handler)


class ProductionConfig(Config):
    '''
        Production configuration
    '''
    APP_ENVIRONMENT = 'production'
    DEBUG = False
    SESSION_COOKIE_SECURE = True


config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'testing': TestingConfig
}




