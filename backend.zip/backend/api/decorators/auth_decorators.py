'''
    auth_decorators.py

    This file contains decorators used to wrap python methods
    This decorators apply the need for authentication to any request
    that goes to the endpoint in question
'''
import os
from functools import wraps
from flask import request, current_app
from flask_restful import abort
import base64


def requires_admin_auth(function):
    '''
        Decorator used to require the admin credentials
        in the form of an HTTP_AUTHORIZATION header
    '''
    @wraps(function)
    def decorated(*args, **kwargs):
        if os.environ.get('AUTHENTICATION', 'True') == 'False':
            return function(*args, **kwargs)

        http_auth = request.environ.get('HTTP_AUTHORIZATION')

        if http_auth:
            auth_type, data = http_auth.split(' ', 1)
            if auth_type == 'Basic':
                try:
                    username, api_key = data.split(':', 1)

                    if username != os.getenv('ADMIN_USERNAME') or api_key != os.getenv('ADMIN_PASSWORD'):
                        current_app.logger.warning('Admin request failed to authenticate!')
                        return abort(401)
                except ValueError:
                    pass
                return function(*args, **kwargs)
            
            auth_string = os.environ.get('ADMIN_USERNAME') + ':' + os.environ.get('ADMIN_PASSWORD')
            auth_bytes = auth_string.encode("utf-8")

            if data.encode("utf-8") == base64.b64encode(auth_bytes):
                return function(*args, **kwargs)
        else:
            return abort(401)
    return decorated


def requires_client_auth(function):
    '''
        Decorator used to require the client credentials
        in the form of an HTTP_AUTHORIZATION header
    '''
    @wraps(function)
    def decorated(*args, **kwargs):
        if os.environ.get('AUTHENTICATION', 'True') == 'False':
            return function(*args, **kwargs)

        http_auth = request.environ.get('HTTP_AUTHORIZATION')

        if http_auth:
            auth_type, data = http_auth.split(' ', 1)
            if auth_type == 'ApiKey':
                try:
                    username, api_key = data.split(':', 1)

                    if username != os.getenv('CLIENT_USERNAME') or api_key != os.getenv('CLIENT_PASSWORD'):
                        current_app.logger.warning('Client request failed to authenticate!')
                        return abort(401)
                except ValueError:
                    pass
                return function(*args, **kwargs)
            
            auth_string = os.environ.get('CLIENT_USERNAME') + ':' + os.environ.get('CLIENT_PASSWORD')
            auth_bytes = auth_string.encode("utf-8")

            if data.encode("utf-8") == base64.b64encode(auth_bytes):
                return function(*args, **kwargs)
        else:
            return abort(401)
    return decorated
