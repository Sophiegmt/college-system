'''
    __init__.py

    File that instanciates the blueprint for the admin API
'''
from flask import Blueprint

# initialize blueprint for the admin api logic
bp = Blueprint('microservices', __name__)

from . import routes
