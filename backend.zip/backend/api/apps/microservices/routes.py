import os
from . import bp
from http import HTTPStatus
from flask import request, make_response, jsonify
# Services
from api.services.request_data_service import RequestDataService
from api.services.post_data_service import PostDataService
from api.services.put_data_service import PutDataService
from api.services.delete_data_service import DeleteDataService
# Values
from api.values.api_error_value import APIErrorValue
# Decorators
from api.decorators.auth_decorators import requires_client_auth


@bp.route('/<string:service_name>', defaults={'subpath': ''})
@bp.route('/<string:service_name>/<path:subpath>', methods=['GET', 'POST', 'PUT', 'DELETE'])
def request_service(service_name, subpath):
    print(subpath)
    filename = f'data/services.txt'
    if not service_name:
        return APIErrorValue('Invalid service name').json(HTTPStatus.BAD_REQUEST)

    try:
        with open(filename, 'r+') as fp:
            data = fp.readlines()
            found_service = False

            for line in data:
                name, db_service_name, endpoint = line.split('_=_', 2)

                if db_service_name == service_name:
                    found_service = True
                    break

    except FileNotFoundError:
        return APIErrorValue('Service not found!').json(HTTPStatus.NOT_FOUND)

    if not found_service:
        return APIErrorValue('Service not found').json(HTTPStatus.NOT_FOUND)

    endpoint = endpoint.rstrip()
    url = f'{endpoint}/{subpath}'

    try:
        if request.method == 'GET':
            response = RequestDataService(
                url=url
            ).call()

        elif request.method == 'POST':
            response = PostDataService(
                url=url,
                data=request.form
            ).call()

        elif request.method == 'PUT':
            response = PutDataService(
                url=url,
                data=request.form
            ).call()

        elif request.method == 'DELETE':
            response = DeleteDataService(
                url=url
            ).call()

        else:
            return APIErrorValue('Bad request').json(HTTPStatus.BAD_REQUEST)

    except:
        return APIErrorValue('Failed to request service!').json(HTTPStatus.SERVICE_UNAVAILABLE)

    data = response.json()

    try:
        resp = make_response(data)
    except:
        data = jsonify(data)
        resp = make_response(data)

    return resp
