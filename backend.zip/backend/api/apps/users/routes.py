import os
from http import HTTPStatus
from flask import request, make_response, jsonify, current_app
from secrets import token_urlsafe
from api.values.api_error_value import APIErrorValue
from api.values.user_value import UserValue
from api.finders.services_finder import ServicesFinder
from api.decorators.auth_decorators import requires_client_auth
from . import bp


@bp.route('/', methods=['POST'])
@requires_client_auth
def create_user():
    print(request.form)
    fullname = request.form.get('fullname', None)
    username = request.form.get('username', None)

    if not fullname or not username:
        return APIErrorValue('Missing parameters').json(HTTPStatus.BAD_REQUEST)

    filename = f'data/users.txt'
    found = False
    saved = False

    try:
        with open(filename, 'r+') as fp:
            data = fp.readlines()

            for cnt, line in enumerate(data):
                saved_fullname, saved_username, code = line.split(':', 2)
                if username == saved_username:
                    return APIErrorValue('User already exists').json(HTTPStatus.BAD_REQUEST)

        with open(filename, 'a+') as fp:
            code = token_urlsafe(6)
            code_registry = f'{fullname}:{username}:{code}\n'
            fp.writelines(code_registry)

    except FileNotFoundError:
        with open(filename, 'w+') as fp:
            code = token_urlsafe(6)
            code_registry = f'{fullname}:{username}:{code}\n'
            fp.writelines(code_registry)
            return APIErrorValue('Failed to create user').json(HTTPStatus.INTERNAL_SERVER_ERROR)

    user = {
        'fullname': fullname,
        'username': username,
        'code': code
    }
    return UserValue(user).json(HTTPStatus.OK)


@bp.route('/<string:username>', methods=['GET'])
@requires_client_auth
def get_user(username):
    filename = f'data/users.txt'

    try:
        with open(filename, 'r+') as fp:
            data = fp.readlines()

            for line in data:
                fullname, saved_username, code = line.split(':', 2)
                if username == saved_username:
                    user = {
                        'fullname': fullname,
                        'username': saved_username,
                        'code': code.rstrip()
                    }

                    return UserValue(user).json(HTTPStatus.OK)

    except:
        return APIErrorValue('User not found').json(HTTPStatus.NOT_FOUND)
    return APIErrorValue('User not found').json(HTTPStatus.NOT_FOUND)


@bp.route('/code', methods=['POST'])
@requires_client_auth
def verify_code():
    code = request.form.get('code', None)

    if not code:
        return APIErrorValue('Code parameter cant be null').json(HTTPStatus.BAD_REQUEST)

    filename = f'data/users.txt'
    result_username = None
    result_fullname = None
    match = False

    try:
        with open(filename, 'r+') as fp:
            data = fp.readlines()

            for cnt, line in enumerate(data):
                fullname, saved_username, saved_code = line.split(':', 2)

                if saved_code.rstrip() == code:
                    result_username = saved_username
                    result_fullname = fullname
                    match = True
                    break

            if match:
                with open(filename, 'w') as fp:
                    fp.writelines(data)

    except FileNotFoundError:
        return APIErrorValue('User not found!').json(HTTPStatus.BAD_REQUEST)

    if not match:
        return APIErrorValue('User not found!').json(HTTPStatus.BAD_REQUEST)

    user = {
        'fullname': result_fullname,
        'username': result_username,
        'code': code.rstrip()
    }
    return UserValue(user).json(HTTPStatus.OK)


@bp.route('/<string:username>/code', methods=['POST'])
@requires_client_auth
def generate_code(username):
    filename = f'data/users.txt'
    found = False
    code_registry = None

    try:
        with open(filename, 'r+') as fp:
            data = fp.readlines()

            for cnt, line in enumerate(data):
                fullname, saved_username, code = line.split(':', 2)

                if username == saved_username:
                    code = token_urlsafe(6)
                    code_registry = f'{fullname}:{username}:{code}\n'
                    data[cnt] = code_registry
                    found = True

        if found:
            with open(filename, 'w') as fp:
                fp.writelines(data)

    except FileNotFoundError:
        return APIErrorValue('Failed to generate code').json(HTTPStatus.INTERNAL_SERVER_ERROR)

    resp = {'code': code}
    return make_response(resp)
