'''
    __init__.py

    File that instanciates the blueprint for the users API
'''
from flask import Blueprint

# initialize blueprint for the admin api logic
bp = Blueprint('users', __name__)

from . import routes
