'''
    routes.py

    This file contains the endpoints of the services blueprint
'''
import os
from http import HTTPStatus
from flask import request, make_response
from .. import bp

from api.services.request_data_service import RequestDataService
from api.services.post_data_service import PostDataService
from api.services.put_data_service import PutDataService
from api.services.delete_data_service import DeleteDataService

from api.finders.services_finder import ServicesFinder

from api.values.api_error_value import APIErrorValue
from api.values.services.services_list_value import ServicesListValue
from api.values.services.service_value import ServiceValue

from api.decorators.auth_decorators import requires_admin_auth


@bp.route('/services', methods=['GET'])
@requires_admin_auth
def list_services():
    '''
        Endpoint used to list all the services
    '''
    services_list = ServicesFinder().get_all_services()

    if not services_list:
        return APIErrorValue('Services list is empty').json(HTTPStatus.NOT_FOUND)

    return ServicesListValue(services_list).json(HTTPStatus.OK)


@bp.route('/services/<string:service_name>', methods=['GET'])
@requires_admin_auth
def get_service(service_name):
    '''
        Endpoint used to retrieve a specific service
    '''
    service = ServicesFinder().get_service_by_name(service_name)

    if not service:
        return APIErrorValue('Service not found').json(HTTPStatus.NOT_FOUND)

    return ServiceValue(service).json(HTTPStatus.OK)


@bp.route("/services", methods=['POST'])
@requires_admin_auth
def create_service():
    '''
        Endpoint used to create a new service
    '''
    data = request.form
    service_name = data.get('service_name', None)
    name = data.get('name', None)
    endpoint = data.get('endpoint', None)

    if not service_name or not name or not endpoint:
        return APIErrorValue('Mssing values').json(HTTPStatus.BAD_REQUEST)

    service = ServicesFinder().get_service_by_name(service_name)

    if service:
        return APIErrorValue('Service already exists').json(HTTPStatus.BAD_REQUEST)

    try:
        filename = f'data/services.txt'
        with open(filename, 'a+') as fp:
            data = f'\n{name}_=_{service_name}_=_{endpoint}'
            fp.writelines(data)

    except FileNotFoundError:
        return APIErrorValue('Failed to get service data').json(HTTPStatus.INTERNAL_SERVER_ERROR)

    return ServiceValue(data).json(HTTPStatus.OK)


@bp.route("/services/<string:service_name>", methods=['PUT'])
@requires_admin_auth
def update_service(service_name):
    '''
        Endpoint used to update an existing service
    '''

    data = request.form
    service_name = data.get('service_name', None)
    name = data.get('name', None)
    endpoint = data.get('endpoint', None)

    if not service_name or not name or not endpoint:
        return APIErrorValue('Mssing values').json(HTTPStatus.BAD_REQUEST)

    filename = f'data/services.txt'
    service_registry = f'{name}_=_{service_name}_=_{endpoint}\n'
    service = None

    try:
        with open(filename, 'r+') as fp:
            data = fp.readlines()

            for cnt, line in enumerate(data):
                name, db_service_name, endpoint = line.split('_=_', 2)

                if service_name == db_service_name:
                    data[cnt] = service_registry

                    service = {
                        'name': name,
                        'service_name': db_service_name,
                        'endpoint': endpoint.rstrip()
                    }
                    break

    except FileNotFoundError:
        return APIErrorValue('Failed to get service data').json(HTTPStatus.INTERNAL_SERVER_ERROR)

    # if there was no code already in the file or it doesnt exist
    if not service:
        return APIErrorValue('Service not found').json(HTTPStatus.NOT_FOUND)

    with open(filename, 'w') as fp:
        fp.writelines(data)

    return ServiceValue(service).json(HTTPStatus.OK)
