'''
    routes.py

    This file contains the endpoints of the canteen blueprint
'''
import os
from http import HTTPStatus
from flask import request, make_response
from .. import bp

from api.services.request_data_service import RequestDataService
from api.services.post_data_service import PostDataService
from api.services.put_data_service import PutDataService
from api.services.delete_data_service import DeleteDataService

from api.finders.services_finder import ServicesFinder

from api.values.api_error_value import APIErrorValue
from api.values.secretariat.secretariat_list_value import SecretariatListValue
from api.values.secretariat.secretariat_value import SecretariatValue

from api.decorators.auth_decorators import requires_admin_auth


@bp.route('/secretariats', methods=['GET'])
@requires_admin_auth
def list_secretariats():
    '''
        Endpoint used to list all the secretariats
    '''
    service = ServicesFinder().get_service_by_name('secretariats')

    if not service:
        return APIErrorValue('Failed to get secretariat service data').json(HTTPStatus.NOT_FOUND)

    try:
        url = service.get('endpoint', None) + '/'
        response = RequestDataService(url=url).call()

    except:
        return APIErrorValue('Failed to request secretariats').json(HTTPStatus.SERVICE_UNAVAILABLE)
    
    if not response:
        secretariats_list = []
    else:
        data = response.json()
        secretariats_list = data['secretariats']

    return SecretariatListValue(secretariats_list).json(HTTPStatus.OK)


@bp.route('/secretariats/<string:secretariat_external_id>', methods=['GET'])
@requires_admin_auth
def get_secretariat(secretariat_external_id):
    '''
        Endpoint used to retrieve a specific
        secretariat by id
    '''
    service = ServicesFinder().get_service_by_name('secretariats')

    if not service:
        return APIErrorValue('Failed to get secretariat service data').json(HTTPStatus.NOT_FOUND)

    try:
        url = service.get('endpoint', None) + '/' + secretariat_external_id
        response = RequestDataService(url=url).call()

    except:
        return APIErrorValue('Failed to request secretariat').json(HTTPStatus.SERVICE_UNAVAILABLE)

    data = response.json()

    if response.status_code == HTTPStatus.BAD_REQUEST:
        return APIErrorValue('Secretariat doesnt exist!').json(HTTPStatus.BAD_REQUEST)

    return SecretariatValue(data).json(HTTPStatus.OK)


@bp.route("/secretariats", methods=['POST'])
@requires_admin_auth
def create_secretariat():
    '''
        Endpoint used to create a new secretariat
    '''
    data = request.form

    service = ServicesFinder().get_service_by_name('secretariats')

    if not service:
        return APIErrorValue('Failed to get secretariat service data').json(HTTPStatus.NOT_FOUND)

    microservice_url = service.get('endpoint', None) + '/'

    try:
        response = PostDataService(url=microservice_url, data=data).call()

    except:
        return APIErrorValue('Secretary creation failed!').json(HTTPStatus.SERVICE_UNAVAILABLE)

    if response.status_code != HTTPStatus.OK:
        return APIErrorValue('Secretary creation failed!').json(HTTPStatus.BAD_REQUEST)

    data = response.json()
    return SecretariatValue(data).json(HTTPStatus.OK)


@bp.route("/secretariats/<string:secretariat_external_id>", methods=['PUT'])
@requires_admin_auth
def update_secretariat(secretariat_external_id):
    '''
        Endpoint used to update an existing secretariat
    '''
    data = request.form

    service = ServicesFinder().get_service_by_name('secretariats')

    if not service:
        return APIErrorValue('Failed to get secretariat service data').json(HTTPStatus.NOT_FOUND)

    microservice_url = service.get('endpoint', None) + f'/{secretariat_external_id}'

    try:
        response = PutDataService(url=microservice_url, data=data).call()

    except:
        return APIErrorValue('Secretary update failed!').json(HTTPStatus.SERVICE_UNAVAILABLE)

    if response.status_code != HTTPStatus.OK:
        return APIErrorValue('Secretary update failed!').json(HTTPStatus.BAD_REQUEST)

    data = response.json()
    return SecretariatValue(data).json(HTTPStatus.OK)


@bp.route("/secretariats/<string:secretariat_external_id>", methods=['DELETE'])
@requires_admin_auth
def delete_secretariat(secretariat_external_id):
    '''
        Endpoint used to delete an existing secretariat
    '''
    service = ServicesFinder().get_service_by_name('secretariats')

    if not service:
        return APIErrorValue('Failed to get secretariat service data').json(HTTPStatus.NOT_FOUND)

    microservice_url = service.get('endpoint', None) + f'/{secretariat_external_id}'

    try:
        response = DeleteDataService(url=microservice_url).call()

    except:
        return APIErrorValue('Secretary deletion failed!').json(HTTPStatus.SERVICE_UNAVAILABLE)

    if response.status_code != HTTPStatus.OK:
        return APIErrorValue('Secretary deletion failed!').json(HTTPStatus.BAD_REQUEST)

    response = {'message': 'Sucessfully deleted secretariat.'}
    return make_response(response, HTTPStatus.OK)
