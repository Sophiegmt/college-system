'''
    __init__.py

    File that instanciates the blueprint for the admin API
'''
from flask import Blueprint

# initialize blueprint for the admin api logic
bp = Blueprint('admin', __name__)

# import endpoints
from .logs import routes
from .secretariat import routes
from .microservices import routes
