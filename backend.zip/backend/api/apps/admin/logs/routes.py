'''
    routes.py

    This file contains the endpoints of the canteen blueprint
'''
import os
from http import HTTPStatus
from flask import make_response, jsonify, current_app, redirect, url_for
from .. import bp
# Services
from api.services.request_data_service import RequestDataService
# Finders
from api.finders.services_finder import ServicesFinder
# Values
from api.values.api_error_value import APIErrorValue
from api.values.logs_value import LogsValue
# Auth decorators
from api.decorators.auth_decorators import requires_admin_auth


@bp.route("/logs/services", methods=['GET'])
@requires_admin_auth
def get_services():
    '''
        Endpoint used to request the available logged
        services
    '''
    services_list = ServicesFinder().get_all_services()

    current_app.logger.info(f'GET /api/logs - {HTTPStatus.OK}')
    return make_response(jsonify(services_list), HTTPStatus.OK)


@bp.route("/logs/<string:service_name>", methods=['GET'])
@requires_admin_auth
def get_service_logs(service_name):
    '''
        Endpoint used to request the logs from
        a specific service
    '''
    if service_name == 'backend':
        return redirect(url_for('admin.get_logs'))

    service = ServicesFinder().get_service_by_name(service_name)

    if not service:
        current_app.logger.info(f'GET /api/logs/{service_name} - {HTTPStatus.BAD_REQUEST}')
        return APIErrorValue('Service doesnt exist!').json(HTTPStatus.BAD_REQUEST)

    try:
        endpoint = service.get('endpoint', None)
        url = f'{endpoint}/logs'

        response = RequestDataService(url=url).call()

    except:
        current_app.logger.info(f'GET /api/logs/{service_name} - {HTTPStatus.SERVICE_UNAVAILABLE}')
        return APIErrorValue('Failed to request logs from external api').json(HTTPStatus.SERVICE_UNAVAILABLE)

    current_app.logger.info(f'GET /api/logs/{service_name} - {HTTPStatus.OK}')
    data = response.json()
    return make_response(data, HTTPStatus.OK)


@bp.route('/logs', methods=['GET'])
@requires_admin_auth
def get_logs():
    '''
        Endpoint used to fetch the logging file
    '''
    log_file = os.path.join(current_app.root_path, 'logs', 'logs.log')

    if log_file is None:
        current_app.logger.error(f'Failed to locate log file')
        current_app.logger.info(f'GET /api/logs - {HTTPStatus.BAD_REQUEST}')
        return APIErrorValue("Failed to fetch log file").json(HTTPStatus.BAD_REQUEST)

    try:
        logs_response = LogsValue(log_file)

    except Exception as error:
        current_app.logger.error(f'Failed to parse log file: {error}')
        current_app.logger.info(f'GET /api/logs - {HTTPStatus.INTERNAL_SERVER_ERROR}')
        return APIErrorValue("Log file doesnt exist").json(HTTPStatus.INTERNAL_SERVER_ERROR)

    current_app.logger.info(f'GET /api/logs - {HTTPStatus.OK}')
    return logs_response.json(HTTPStatus.OK)
