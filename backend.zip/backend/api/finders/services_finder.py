'''
    ServicesFinder is used to retrieve data from the services containing file
'''


class ServicesFinder():

    def __init__(self):
        self.filename = 'data/services.txt'

    def get_all_services(self):
        '''
            Method used to retrieve all the existing services from the file
        '''
        with open(self.filename, 'r+') as fp:
            data = fp.readlines()
            services = []

            for line in data:
                name, db_service_name, endpoint = line.split('_=_', 2)

                service = {
                    'name': name,
                    'service_name': db_service_name,
                    'endpoint': endpoint.rstrip()
                }
                services.append(service)

        if not services:
            return None

        return services


    def get_service_by_name(self, service_name):
        '''
            Method used to retrieve a specific service from the file
        '''
        with open(self.filename, 'r+') as fp:
            data = fp.readlines()
            found_service = False

            for line in data:
                name, db_service_name, endpoint = line.split('_=_', 2)

                if db_service_name == service_name:
                    found_service = True
                    break

        if not found_service:
            return None

        service = {
            'name': name,
            'service_name': db_service_name,
            'endpoint': endpoint.rstrip()
        }

        return service
