'''
    put_data_service.py

    This file contains the service used to make
    PUT requests to any URL
'''
from flask import current_app
import requests


class PutDataService():
    '''
        Service used to make a request using a PUT method

        Parameters:
        - url: the base url of the API
        - timeout: time limit, in seconds, to receive a response
                    from the API
        - data: payload to send

        Returns:
        - response: data from the api
    '''

    def __init__(self, url, data):
        self.url = url
        self.timeout = self.timeout = current_app.config.get('REQUEST_TIMEOUT')
        self.data = data

        username = current_app.config.get('MICROSERVICES_ADMIN_USERNAME')
        password = current_app.config.get('MICROSERVICES_ADMIN_PASSWORD')
        self.headers = {
            'Authorization': f'Basic {username}:{password}'
        }

    def call(self):
        try:
            response = requests.put(
                url=self.url,
                data=self.data,
                headers=self.headers,
                timeout=self.timeout
            )

            # if the answer is not 200, raise an exception
            response.raise_for_status()

        # if the request fails, raise the exception and log it
        except Exception as error:
            current_app.logger.error(f'Failed to make PUT request: {error}')
            raise
        
        current_app.logger.info(f'Sucessful PUT request to {self.url}')
        return response
