from api.values.value_composite import ValueComposite


class SecretariatValue(ValueComposite):
	def __init__(self, secretariat):
		super(SecretariatValue, self).initialize({})
		self.serialize_with(name=secretariat['name'])
		self.serialize_with(location=secretariat['location'])
		self.serialize_with(description=secretariat['description'])
		self.serialize_with(opening_hours=secretariat['opening_hours'])
		self.serialize_with(closing_hours=secretariat['closing_hours'])
		self.serialize_with(created_at=secretariat['created_at'])
		self.serialize_with(updated_at=secretariat['updated_at'])
		self.serialize_with(external_id=secretariat['external_id'])
