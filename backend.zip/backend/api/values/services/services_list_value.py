from api.values.value_composite import ValueComposite
from api.values.services.service_value import ServiceValue


class ServicesListValue(ValueComposite):
    def __init__(self, services):
        super(ServicesListValue, self).initialize({})

        services_list = []
        for service in services:
            services_list.append(ServiceValue(service).to_dict())

        self.serialize_with(services=services_list)
