from api.values.value_composite import ValueComposite


class ServiceValue(ValueComposite):
	def __init__(self, service):
		super(ServiceValue, self).initialize({})
		self.serialize_with(name=service['name'])
		self.serialize_with(service_name=service['service_name'])
		self.serialize_with(endpoint=service['endpoint'])
