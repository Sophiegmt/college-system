from api.values.value_composite import ValueComposite


class LogsValue(ValueComposite):
    """Used to serialize logs from a file to a json 

    Attributes:
        log_file: A string describing file containing logs
    """

    def __init__(self, log_file):
        super(LogsValue, self).initialize({})

        logs_list = []

        with open(log_file) as fp:
            for line in reversed(list(fp)):
                log = {'text': line}
                logs_list.append(log)


        self.serialize_with(list=logs_list)
